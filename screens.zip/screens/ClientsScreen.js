
import React, {useState} from 'react';
import {Searchbar, Button, Menu, Divider, Provider, TextInput } from 'react-native-paper';
import {
  StyleSheet,
  Text,
  View,
   ScrollView,
  SafeAreaView,
  SectionList,
  StatusBar,
} from 'react-native';











const DATA = [
  {
    title: 'Contatos',
    data: ['*'],
  },
  {
    title: 'A',
    data: ['Afulana', 'Afulane', 'A outra'],
  },
  {
    title: 'B',
    data: ['contatinho1', 'contatinho2', 'Contador'],
  },
  {
    title: 'D',
    data: ['Diana- grupo de Libras', 'Diná- Representante do grupo Cultura Surda'],
  },
];















const ContatosPAG = (props) => {
  return (
    <View style={styles.screen}>
    







 <SafeAreaView style={styles.container}>
  <ScrollView>
    <SectionList
      sections={DATA}
      keyExtractor={(item, index) => item + index}
      renderItem={({item}) => (
        <View style={styles.item}>
          <Text style={styles.title}>{item}</Text>
        </View>
      )}
      renderSectionHeader={({section: {title}}) => (
        <Text style={styles.header}>{title}</Text>
      )}
    />
    </ScrollView>
  </SafeAreaView>












    </View>
  );
};

export default ContatosPAG

const styles = StyleSheet.create({
screen: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
},


  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
    marginHorizontal: 16,
  },
  item: {
    backgroundColor: '#blue',
    padding: 20,
    marginVertical: 8,
  },
  header: {
    fontSize: 32,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
  },
});

